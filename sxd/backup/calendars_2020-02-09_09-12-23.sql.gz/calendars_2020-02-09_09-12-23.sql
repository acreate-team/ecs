#SXD20|20011|50556|50416|2020.02.09 09:12:23|calendars|0|7|32|
#TA auth_assignment`1`16384|auth_item`12`16384|auth_item_child`10`16384|auth_rule`1`16384|page`1`32768|settings`5`16384|user`2`16384
#EOH

#	TC`auth_assignment`utf8_unicode_ci	;
CREATE TABLE `auth_assignment` (
  `item_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`item_name`,`user_id`),
  CONSTRAINT `auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`auth_assignment`utf8_unicode_ci	;
INSERT INTO `auth_assignment` VALUES 
('admin','1',1497790312)	;
#	TC`auth_item`utf8_unicode_ci	;
CREATE TABLE `auth_item` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `rule_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` blob,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `rule_name` (`rule_name`),
  KEY `idx-auth_item-type` (`type`),
  CONSTRAINT `auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`auth_item`utf8_unicode_ci	;
INSERT INTO `auth_item` VALUES 
('add',2,\N,\N,\N,1497790312,1497790312),
('admin',1,\N,'userRole',\N,1497790312,1497790312),
('delete',2,\N,\N,\N,1497790312,1497790312),
('edit',2,\N,\N,\N,1497790312,1497790312),
('editor',1,\N,'userRole',\N,1497790312,1497790312),
('fileManager',2,\N,\N,\N,1497790312,1497790312),
('fileUpload',2,\N,\N,\N,1497790312,1497790312),
('imageManager',2,\N,\N,\N,1497790312,1497790312),
('imageUpload',2,\N,\N,\N,1497790312,1497790312),
('status',2,\N,\N,\N,1497790312,1497790312),
('user',1,\N,'userRole',\N,1497790312,1497790312),
('view',2,\N,\N,\N,1497790312,1497790312)	;
#	TC`auth_item_child`utf8_unicode_ci	;
CREATE TABLE `auth_item_child` (
  `parent` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `child` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`),
  CONSTRAINT `auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`auth_item_child`utf8_unicode_ci	;
INSERT INTO `auth_item_child` VALUES 
('admin','delete'),
('admin','editor'),
('editor','add'),
('editor','edit'),
('editor','fileManager'),
('editor','fileUpload'),
('editor','imageManager'),
('editor','imageUpload'),
('editor','status'),
('editor','view')	;
#	TC`auth_rule`utf8_unicode_ci	;
CREATE TABLE `auth_rule` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `data` blob,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`auth_rule`utf8_unicode_ci	;
INSERT INTO `auth_rule` VALUES 
('userRole','O:36:\"common\\components\\rbac\\UserGroupRule\":3:{s:4:\"name\";s:8:\"userRole\";s:9:\"createdAt\";i:1497790312;s:9:\"updatedAt\";i:1497790312;}',1497790312,1497790312)	;
#	TC`page`utf8_general_ci	;
CREATE TABLE `page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `date_update` int(11) NOT NULL,
  `date_create` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8	;
#	TD`page`utf8_general_ci	;
INSERT INTO `page` VALUES 
(16,'test','Проверочная страница','<h1>Заголовок 1</h1><h2>Заголовок 2</h2><p>Текст</p><ul><li>Список</li><li>Список</li></ul><p>Чтобы делать - надо знать, чтобы знать - надо лелать.</p>','','',1,1578908748,1578664390),
(18,'gksgrigorianskayakalendarnayasistema','ГКС = григорианская календарная система.','<p><strong>ГКС = григорианская календарная система</strong></p>  <hr>    <p><strong>Недостатки ГКС</strong><strong>.</strong></p>    <p>ГКС (календарная система григорианская) - это система календарирования времени (система отсчет времени, система счета времени, система расчета времени), в основе которой лежит непрерывная последовательность седмиц: 1 нед = 7 сут (название и последовательность дней недели: пн, вт, ср, чт, пт, сб, вс). В существующем сегодня формате (тематический стандарт системы), ГКС, имея удовлетворительный отсчёт, счёт, расчёт времени в целом, имеет крайне неудовлетворительную делимость внутренних частей, которая, нарушая законы и принципы календарной гармонии, проявляется в следующем:</p>  <p><strong></strong></p>  <p><strong>объёмные несоразмерности (проблемы в стандартизации):</strong></p>  <p>1 юга (4-летний цикл) = 1460-1461 сут</p>  <p>1 год (1-летие) = 365-366 сут</p>  <p>1 аспид (1 полугодие) = 181-184 сут</p>  <p>1 тэкуф (1 сезон, 1 квартал) = 90-92 сут</p>  <p>1 месяц = 28-31 сут<strong></strong></p>  <p>то есть, ни один человек в мире не может дать точный ответ на вопрос: что такое календарный месяц, квартал, полугодие, год, юга?</p>    <p>Ø<strong>гибридная аномальность (впихание в невпихуемое):</strong></p>  <p>дни недели не совпадают счислами месяца (редко можно встретить человека, который помнил бы свой день рождения по дням недели)</p>  <p>продолжительность недели не связана с продолжительностью месяца, квартала, полугодия, года, юги (ни 1460, ни 1461 на 7 не делятся)</p>  <p>начала месяцев, кварталов, полугодий, годов, юг приходятся на разные дни недели</p>  <p>место високоса в календаре не связано с функцией високоса в природе (високос = демаркация двух 4-летних циклов, которая находиться в конце последнего года 4-летнего цикла)</p>  <p>отсутствие календарных дат (после 05 окт 1582 года идет 14 окт 1582 года, то есть, 10-и суток в календаре нет)</p>  <p><strong></strong></p>  <p>Ø<strong>начальные несоответствия (несуразица на несуразицу):</strong></p>  <p>начало времяисчисления (р.х. = 0 = эра) не соответствует дате рождения Иисуса Христа (Рождество Христово- это гипотетическая точка отсчета времени)</p>  <p>начало летоисчисления (01 янв) не соответствует началу природного цикла (весна/лето/осень/зима)</p>  <p>начало годоизмерения (01 янв) не соответствует началу расчётного цикла (високос = 29 фев = конец 4-летнего цикла, приходится на конец третьего месяца года)</p>    <p><strong>ГКС можно сравнить с часами, в которых:</strong></p>  <p>между 1 и 2 часом - 50 мин</p>  <p>между 2 и 3 часом - 70 мин</p>  <p>между 3 и 4 часом - 45 мин</p>  <p>и т.д. и т.п. на протяжении всех суток, хотя, в общем, продолжительность суток равна:</p>  <p>1 сут = 24 час</p>  <p>1 сут = 1 440 мин</p>  <p>1 сут = 86 400 сек</p>  <p><strong></strong></p>  <p><strong>Проблемы ГКС.</strong></p>  <p>01.28-летний цикл.</p>  <p>В ГКС существует два типа календарных годов: эмболисный (1 год = 365 сут) и високосный (1 год = 366 сут). Посколькугод в ГКС может начинаться с любого дня недели, это дает 7 типов эмболисных и 7 типов високосных годов (14 типов календарных годов =14 типов календарных таблиц), которыеповторяются через каждые 28 лет.</p>  <p>02.400-летний цикл.</p>  <p>ГКС - это система календарирования времени, основанная на циклическом обращении земли относительносолнца; продолжительность года в ГКС принята равной 365,2425 сут; содержит в интервале 400-летия 3 эмболисных и 97 високосных годов (146097 : 400 = 365,2425 сут). Это нарушает структуру 28-летнего цикла.</p>  <p>03.22 400-летний цикл.</p>  <p>8 181 425 сут : 22 400 лет = 365,2421875 сут. Вот таким большим интервалом времени нужно пользоваться, чтобы проверить абсолютную продолжительность обращения Земли относительно Солнца (периодическая цикличность григорианской календарной системы).</p>  <p>04.Системы календарирования.</p>  <p>В ГКС отсутствуют системы календарирования времени, которые давали бы общее видение разных событий на одной календарной площадке.</p>  <p>05.Отсутствие дат.</p>  <p>В ГКС отсутствуют реальные календарные сутки в 1582 от р.х. А именно, после 05 октября 1582 года идет 14 октября 1582 года, то есть, 10-и суток в календаре нет. Историческая справка: григорианский календарь был введён римским папой Григорием XIII в католических странах 04 окт 1582 года вместо юлианского календаря (следующим днём после четверга 04 октября стала пятница 15 октября).</p>  <p>06.Система отсчета.</p>  <p>Ни юлианский, ни григорианский календарь не ведут отсчёт времени от р.х. Юлианский календарь был принят в 45 году до р.х., а начал нормально функционировать с 8 года от р.х. Григорианский календарь начинается с 1582 года от р.х. = начало (эра) григорианской системы календарирования времени.</p>  <p>07.Интеркаляционная система.</p>  <p>По ГКС не понятно: 1 год до р.х. високосный или эмболисный (1582-400-400-400-400 = 18 год до р.х.).</p>  <p>08.Календарные блоки.</p>  <p>В ГКС отсутствует блочная система календарирования времени (система стандартных единиц), дающая удобный отсчет, счет, расчет времени.</p>  <p>09.Эталон года.</p>  <p>В ГКС нет расчета для определения календарного эталона года: число «шэ» = 365,2421875 сут = величина одного обращения Земли относительно Солнца.</p>  <p>10.Система нумерации.</p>  <p>В ГКС не систематизирована нумерация недель в бумажных календарях (карманных, настольных, настенных) = первая неделя года начинается не с 01 января, а по несуразным правилам.</p>  <p>11.Финансовые расходы.</p>  <p>Изготовление григорианских календарей - это огромные расходы и затраты на носители календарной информации: бумага, производство, трудодни.</p>  <p>12.Вред природе.</p>  <p>Вопрос: сколько уничтожается деревьев для обеспечения годового выпуска бумажных календарей (настенных, настольных, карманных, …).</p>  <p>13.<strong>…</strong></p>    <p><strong>Парадоксы ГКС.</strong></p>  <p>1.В ГКС календарный цикл заканчивается числом, которое логически мыслящий человек принимает за начало, а не за конец счета времени; пример, 2000 год = это начало нового 1000-летия или конец старого 1000-летия?</p>  <p><a href=\"https://yandex.ru/video/search?filmId=145847887315204503&text=%22%D0%BF%D0%B0%D1%80%D0%B0%D0%B4%D0%BE%D0%BA%D1%81%D1%8B%20%D0%B8%20%D0%BE%D1%88%D0%B8%D0%B1%D0%BA%D0%B8%20%D0%BA%D0%B0%D0%BB%D0%B5%D0%BD%D0%B4%D0%B0%D1%80%D0%B5%D0%B9%22&reqid=1524931446208512-258880619512401257532505-vla1-1785-V\">https://yandex.ru/video/search?filmId=145847887315204503&text=%22%D0%BF%D0%B0%D1%80%D0%B0%D0%B4%D0%BE%D0%BA%D1%81%D1%8B%20%D0%B8%20%D0%BE%D1%88%D0%B8%D0%B1%D0%BA%D0%B8%20%D0%BA%D0%B0%D0%BB%D0%B5%D0%BD%D0%B4%D0%B0%D1%80%D0%B5%D0%B9%22&reqid=1524931446208512-258880619512401257532505-vla1-1785-V</a>= отсутствие нуля, летосчисление славян (точка отсчета от смзх, а не от р.х.).</p>  <p>2.Не многие из нас могут ответить на вопрос: что такое 13-я зарплата? Большинство людей думает, что это премия, которую дает великодушный работодатель. На самом деле ответ звучит иначе: в году 12 мес по 28 сут - это те сутки, за которые мы получаем деньги, а 29, 30, 31-е сутки в интервале года дают целый месяц, за который честный работодатель должен честно заплатить рабочему (а честное государство должно честно заплатить пенсионеру).</p>  <p>3.…</p>  <p><strong></strong></p>  <p><strong>Вот такой несуразной конструкцией, которая лежит в основе нашего календаря, мы и пользуемся, и привыкли к ней, и на её основе строим всю свою жизнь.</strong></p>','','',1,1578909175,1578908831)	;
#	TC`settings`utf8_general_ci	;
CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `section` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `value` text,
  `active` tinyint(1) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_unique_key_section` (`section`,`key`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8	;
#	TD`settings`utf8_general_ci	;
INSERT INTO `settings` VALUES 
(1,'string','app','title','ЕКС - единая каледарная система',1,'2017-05-15 01:55:59','2020-01-15 17:13:52'),
(5,'string','app','keywords','',1,'2017-05-15 02:05:13','2019-12-17 12:39:45'),
(6,'string','app','description','',1,'2017-05-15 02:05:30','2019-12-17 12:39:45'),
(11,'string','email','admin','mail@mail.ru',1,'2017-05-15 02:22:39','2020-01-10 16:47:10'),
(12,'string','cms','version','0.1',1,'2017-05-22 08:24:44','2019-12-17 12:35:54')	;
#	TC`user`utf8_unicode_ci	;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '10',
  `role` tinyint(2) NOT NULL DEFAULT '1',
  `ip` varchar(16) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0.0.0.0',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `last_request_time` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `password_reset_token` (`password_reset_token`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`user`utf8_unicode_ci	;
INSERT INTO `user` VALUES 
(2,'toOx','UunH8fazJ21Li_rk5tg6o1OvkFX5D_qM','$2y$13$rxodAG1uCxA2VaScc.w6CuPMq662.LQ70lLMvU0PHy.Hv3RCMJhqO',\N,'toijer@gmail.com',10,10,'0.0.0.0',1578664253,1579175985,1579175985),
(20,'Admin','sjVG5I3WLbuSh-Y_OvIGU762JJ2ajlfd','$2y$13$BXinTCIrTjK4wWXG.02LSe4GMCEVA6rwMXoL5WS44gcqrPDMf5noq',\N,'admin@mail.ru',10,10,'0.0.0.0',1578664253,1579722942,1579722942)	;
